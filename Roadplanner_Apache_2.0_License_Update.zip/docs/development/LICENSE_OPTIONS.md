# Project license decision

## Decision

Roadplanner source code and project documentation are licensed under the **Apache License, Version 2.0**.

The authoritative license text is stored in the repository root as `LICENSE`. Project attribution information is stored in `NOTICE`.

## Why Apache-2.0

The project selected Apache-2.0 because it is a permissive open-source license that:

- permits private, commercial and open-source use, modification and redistribution;
- includes an explicit patent license from contributors;
- requires retention of copyright, license and applicable attribution notices;
- allows Roadplanner to remain usable in Home Assistant, HACS and possible future applications without requiring derivative applications to use the same license.

## Contribution policy

Intentional contributions submitted to this repository are accepted under Apache-2.0 unless explicitly marked as "Not a Contribution". Contributors must have the right to submit their work and must disclose third-party code, assets or data together with the applicable license and attribution requirements.

## Trademark note

The software license does not grant rights to Roadplanner names, logos or other trademarks beyond reasonable and customary attribution.
